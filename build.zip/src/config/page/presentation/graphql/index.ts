import { pageQuery } from "./page.query";

export const pageResolvers={
    Query:pageQuery
}