export interface IPageRepo{

    getPages()
}