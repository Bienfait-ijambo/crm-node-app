


// truncate table account_type  cascade;
// truncate table mass cascade;