### todo
- write test
- publish in my npm repository
- try to install it in project
- improve and refactor............in the future