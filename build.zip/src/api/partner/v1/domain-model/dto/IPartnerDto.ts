export interface IPartnerDto{
    id:number
    name:string
    email:string
    telephone:string
    userId:number
}