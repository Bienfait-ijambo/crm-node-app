export interface IServiceDto{
    id:number;
    name:string;
    userId:number;
}