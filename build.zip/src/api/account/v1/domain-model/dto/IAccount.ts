export interface IAccountDto{
    id:number;
    name: string;
    code:string;
    typeId:number;
    massId:number
    userId:number
}