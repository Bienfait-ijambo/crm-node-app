export interface ITreasuryDto{
    accountId:number
    totalAmount:string
    userId:number
    transactionType:number
}