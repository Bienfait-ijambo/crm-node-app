import { aggregateAccountQuery } from "./aggregateAccount.mutation";

export const aggregateAccountResolver={
    Query:aggregateAccountQuery
}