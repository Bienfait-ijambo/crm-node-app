export interface AggregateAccountDto{
    accountId:number
    accountType:number
    totalAmount:string
    userId:number
}