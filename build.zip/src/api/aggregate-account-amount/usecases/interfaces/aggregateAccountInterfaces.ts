import { enumAccountType } from "../../../../entities/AccountType"
import { enumMassType } from "../../../../entities/Mass"

export interface IGetTreasuryAccountInput{

    userId:number

}
