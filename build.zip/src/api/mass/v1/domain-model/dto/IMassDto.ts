export interface IMassDto{
    id:number
    name:string
    status:number
}