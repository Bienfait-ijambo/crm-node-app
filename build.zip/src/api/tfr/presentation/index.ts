import { TfrQueries } from "./tfr.query";
import { TfrMutations } from "./trf.mutation";


export const tfrResolvers={
    Query:TfrQueries,
    Mutation:TfrMutations
}