export interface IProjectDto {
  id: number;
  designation: string;
  amount:string
  partnerId: number;
  userId: number;
  status:number
}
