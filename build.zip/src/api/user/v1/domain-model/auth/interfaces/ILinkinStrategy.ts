
export interface ILinkedInStrategy {
    id: string;
    displayName: string;
    name:{familyName: string,givenName: string},
    email:string
    photo:string
  
}



