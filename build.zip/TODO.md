
### MAIL ISSUE

* sending beautiful email


## security issue on the frontend

* implement cookie http-only in production[remove localstorage]




### JOURNAL
* test project page to find bug
* pagination [to implement in second proto] for report

## FIX APP DESIGN

---- fix dashboard design

--- CHECK FLOAT NUMBERS
--- numero piece justificative

- optimize journal-page query
- reduce-journal-code


### PRIORITY TASKS

- handling-exceptions in redis in case redis is not running
- correct project page (1)
- add a refresh button on dashboard(correct pie chart) (2)
- correct dashboard design for firstTime login (2)


- implement microsoft strategy
- validation du nom de service[charactère invalid---->change message]
- REDIS implementation (account-table)
- build-pricing
- build-landing page
- add engine in package json nodejs


### NOT PRIORITY TASKS (TO DO LATER)



### UBS FINANCE

- user created by owners will have different emails[like=>user10@]
- update user permissions not working
- fix general-ledger[d]
- init journalModal on open
- correct accountDetailModal [add-report-button]
- add microsft strategy

### THINK ABOUT CACHING STRATEGIES
- backend 
- frontend
- redis

### 


## DASHBOARD
add filter on dashboard

### HANDLE ERROR ====> TO FIX ERROR
An error occurred in getTransactionDetailByAccount:args:[object Object]
 getTransactionDetailByAccount:args:[object Object]

 An error occurred in getTransactionDetailByAccount:args:[object Object]
